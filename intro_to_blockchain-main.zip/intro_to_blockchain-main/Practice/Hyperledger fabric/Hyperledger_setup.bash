# HYPERLEDGER - FABRIC
1.  sudo apt install golang-go
2.  docker –version
3.  docker-compose –version
4.  ls
5.  git clone -b main https://github.com/hyperledger/fabric-samples.git
6.  cd fabric-samples
7.  curl -sSL https://bit.ly/2ysbOFE | bash -s
8.  cd test-network
9.   ./network.sh
10.   ./network.sh up
11.    ./network.sh createChannel
12.    ./network.sh down
